import React from "react";
import Nav from "./Nav";
import UserCard from "./UserCard";

const LandingPage = () => {
  return (
    <div>
      <header>
        <h1>Pokedex</h1>
        <Nav />
      </header>
      <main>
        {/* BULBASAUR */}
        <UserCard
          name="Bulbasaur"
          imgPath={"../assets/img/bulbasaur.jpg"}
          type="Grass"
        />
        {/* CHARMANDER */}
        <UserCard name="Charmander" imgPath={"../assets/img/charmander.jpg"} type="Fire" />
        {/* SQUIRTLE */}
        <UserCard name="Squirtle" imgPath={"../assets/img/squirtle.jpg"} type="Water" />

        {/* will not function... */}
      </main>
      <button className="load-btn">Load More...</button>
      <footer className="contact" id="contact">
        <p>
          <strong>Email :</strong> professorOak@palletTown.com
        </p>
        <p>
          <strong>Phone :</strong> +1 (555) 555 - 5555
        </p>
      </footer>
    </div>
  );
};

export default LandingPage;
