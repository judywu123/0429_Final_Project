import React from "react";

const Nav = () => {
  return (
    <nav>
      <ul className="nav-top">
        <li>
          <a href="top">trainer info</a>
        </li>
        <li>
          <a href="posts">pokemon</a>
        </li>
        <li>
          <a href="#contact">contact</a>
        </li>
      </ul>
    </nav>
  );
};

export default Nav;
