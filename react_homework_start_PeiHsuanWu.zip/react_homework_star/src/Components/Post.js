import React from "react";

const Post = ({ title, date, description }) => {
  return (
    <div className="post">
      <h2>{title}</h2>
      <h4>{date}</h4>
      <p>{description}</p>
    </div>
  );
};

export default Post;
