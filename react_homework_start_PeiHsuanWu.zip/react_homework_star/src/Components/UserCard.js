import React from "react";

const UserCard = ({ name, type, imgPath }) => {
  return (
    <div className="user-card">
      <h2>Name: {name}</h2>
      <img src={imgPath} alt={name} className="character-img" />
      <h4>Type: {type}</h4>
    </div>
  );
};

export default UserCard;
